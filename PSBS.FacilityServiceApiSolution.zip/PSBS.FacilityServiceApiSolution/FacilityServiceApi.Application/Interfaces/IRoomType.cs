﻿using FacilityServiceApi.Domain.Entities;
using PSPS.SharedLibrary.Interface;


namespace FacilityServiceApi.Application.Interfaces
{
    public interface IRoomType : IGenericInterface<RoomType>
    {
    }
}
